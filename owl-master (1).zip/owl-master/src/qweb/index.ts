import "./base_directives";
import "./extensions";

export { CompiledTemplate, QWeb } from "./qweb";
